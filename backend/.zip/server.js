require('dotenv').config({ path: __dirname + '/.env' });
const express    = require('express');
const http       = require('http');
const { Server } = require('socket.io');
const cors       = require('cors');
const path       = require('path');

const app    = express();
const server = http.createServer(app);
const io     = new Server(server, {
  cors: { origin: '*', methods: ['GET','POST','PUT','DELETE'] },
  transports: ['websocket', 'polling'],
});

// ── MIDDLEWARE ────────────────────────────────────────────
app.use(cors({ origin: '*' }));
app.use(express.json());

// ── API ROUTES ────────────────────────────────────────────
app.use('/api/auth',          require('./routes/auth'));
app.use('/api/trips',         require('./routes/trips'));
app.use('/api/bookings',      require('./routes/bookings'));
app.use('/api/checkins',      require('./routes/checkins'));
app.use('/api/ratings',       require('./routes/ratings'));
app.use('/api/notifications', require('./routes/notifications'));
app.use('/api/location',      require('./routes/location'));
app.use('/api/users',         require('./routes/users'));
app.use('/api/geocode',       require('./routes/geocode'));
app.use('/api/pool',          require('./routes/pool'));

// ── SOCKET.IO REAL-TIME TRACKING ──────────────────────────
require('./socket/tracking')(io);

// ── HEALTH CHECK ──────────────────────────────────────────
app.get('/api/health', (req, res) => res.json({ status: 'ok', time: new Date() }));

// ── SERVE FRONTEND BUILD ──────────────────────────────────
// Points to frontend/dist relative to backend folder
const DIST = path.join(__dirname, '../frontend/dist');
app.use(express.static(DIST));

// All non-API routes → serve React index.html (SPA routing)
app.get('*', (req, res) => {
  res.sendFile(path.join(DIST, 'index.html'));
});

// ── START ─────────────────────────────────────────────────
const PORT = process.env.PORT || 3001;
server.listen(PORT, '0.0.0.0', async () => {
  console.log(`\n🚐  Waslney running on port ${PORT}`);
  console.log(`🔌  Socket.io ready`);
  console.log(`📦  Health: http://localhost:${PORT}/api/health\n`);

  // Run DB migrations
  try {
    await require('./migrate')();
  } catch (e) {
    console.error('Migration error:', e.message);
  }
});
